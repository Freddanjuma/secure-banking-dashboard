import React from "react";
import { useNavigate } from "react-router-dom";

function Dashboard() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <div className="dashboard-container">
      <h2>Welcome to Belfius Dashboard</h2>
      <p>Available Balance: €12,480.37</p>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
}

export default Dashboard;